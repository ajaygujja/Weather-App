package com.example.verygoodcore

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity() {
}